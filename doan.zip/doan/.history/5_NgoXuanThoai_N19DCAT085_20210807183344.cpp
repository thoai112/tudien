#include "5_NgoXuanThoai_N19DCAT085.h"
#include <iostream>
#include <stdio.h>
#include <Windows.h>
#include <conio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fstream>
using namespace std;



struct NODEDS
{
	char data[1000];
	NODEDS *next;
};
typedef struct NODEDS NodeDS; 

struct LIST
{
	NodeDS *pHead;
	NodeDS *pTail;
};
typedef struct LIST List;

struct Word
{
	char TuVung[100];
	char LoaiTu[20];
	List Nghia;
	List ViDu;
};

struct Node
{
	Word data;
	Node *left;
	Node *right;
	Node *next;
};
typedef Node *Tree;

// CHUC NANG //
void ThemKiTu(char *chuoi, char dau)
{
	int n = strlen(chuoi);
	n++;
    for(int i=n;i>0;i--)
    {
        chuoi[i] = chuoi[i-1];
    }
    chuoi[0] = dau;
    chuoi[n+1] = '\0'; 
}

void XoaKiTu(char *chuoi, char kiTu)
{
    int n = strlen(chuoi);
    for(int i=0;i<n;i++)
    {
        if(chuoi[i]==kiTu)
        {
            for(int j=i; j<n;j++)
                chuoi[j]=chuoi[j+1];
            break;
        }	
    }
}

void XoaGoiY()
{
	int k=0;
	int x= 10, y= 12;
	int a = x -6;
	int b = y +2;
	for(int i= 0; i< 21; i++)
	{
		gotoxy(a, b+k);
		for(int j = 0; j< 38; j++)
			cout << " ";
		k++;
	}
}

void XoaKetQuaTimKiem()
{
	int x= 10, y= 12;
	int a = x+34;
	int b = y+3;
	for(int i=0; i< 20; i++)
	{
		gotoxy(a, b+i);
		for(int j = 0; j < 57;j++)
			cout << " ";
	}
	for(int i=0; i< 49; i++)
	{
		gotoxy(52+ i, 12);
		cout <<" ";
	}
	for(int i=0; i< 50; i++)
	{
		gotoxy(51+ i, 14);
		cout <<" ";
	}
}
int Max(int a, int b)
{
    return (a > b)? a : b;
}

//Cay nhi phan

Node* newNode(Word key)
{
    Node* node = (Node*) malloc(sizeof(Node));
    node->data = key;
    node->left = NULL;
    node->right = NULL;
    return(node);
}
 
Node *InsertNode(Tree root, Word word)
{
    if (root==NULL)
    {	
		root=newNode(word);
    }
    else
    {	
		int res = strcmp(root->data.TuVung, word.TuVung);
        if (res>0)
        root->left = InsertNode(root->left, word);
    	else
        if (res<0)
        root->right = InsertNode (root->right, word);
    }
    
}
//danh sach lien ket
void Init(List &l)
{
	l.pHead = NULL;
	l.pTail = NULL;
}

NodeDS* GetNode(char *data)
{
	NodeDS *p = new NodeDS;
	if(p==NULL)
        return NULL;
	strcpy(p->data, data);
	p->next = NULL;
	return p;
}

void AddTail(List &l, char *data)
{
	NodeDS *p = GetNode(data);
	if(l.pHead == NULL)
	{
		l.pHead = l.pTail = p;
		
	}
	else 
	{
		l.pTail->next = p;
		l.pTail = p;
	}
}

void DocFile(Tree &root, ifstream &filein)
{	
	root=NULL;
	char temp1[100];
	Word word;
	Init(word.Nghia);
	Init(word.ViDu);
	
	while(filein.getline(temp1,1000) && "\n")
	{   
		
		if(strstr(temp1, "@"))
		{
			if(strlen(word.TuVung) > 0)
			root=InsertNode(root, word);
			Init(word.Nghia);
			Init(word.ViDu);
			strcpy(word.TuVung, temp1);

		}
		else if(strstr(temp1, "*"))
		{
			strcpy(word.LoaiTu,temp1);
		}
		else if(strstr(temp1, "#"))
		{
			AddTail(word.ViDu, temp1);
		}
		else
		{
			AddTail(word.Nghia, temp1);
		}
	}
	root=InsertNode(root,word);
	
	
	
}

void GhiFile(Tree &root, ofstream &fileout)
{	
	if(root!=NULL)
	{
		if(strstr(root->data.TuVung, "@"))
		{
			fileout <<root->data.TuVung <<endl;
		}
		if(strstr(root->data.LoaiTu, "*"))
		{
			fileout << root->data.LoaiTu <<endl ;
		}
	
		NodeDS *nghia = root->data.Nghia.pHead;
		while(nghia!=NULL)
			{	
				fileout <<nghia->data <<endl;
				nghia = nghia->next;
			}
		NodeDS *vidu = root->data.ViDu.pHead;
		while(vidu!=NULL)
			{	
				fileout <<vidu->data <<endl;
				vidu = vidu->next;
			}
		GhiFile(root->left,fileout);
		GhiFile(root->right, fileout);	
	}
	else
	{
		return;
	}
		
}

void Xuat(Tree &root, int&h, int&i, int&k, int &z)
{	
	if(root!=NULL)
	{
		Xuat(root->left,h,i,k,z);
		cout<<endl;
		if(strstr(root->data.TuVung, "@"))
		{
		gotoxy(3,7+h); 
		cout<<z<<endl;
		gotoxy(7,7+h);
		cout<<root->data.TuVung ;
		z++;
		}
		gotoxy(24,7+h);
		if(strstr(root->data.LoaiTu, "*"))
        cout <<root->data.LoaiTu;
		NodeDS* nghia = root->data.Nghia.pHead;
		while (nghia != NULL)
        {	
			gotoxy(36,6+h+i);
            cout << nghia->data<<endl;
            nghia = nghia->next;
			i++;
        }
		NodeDS* vd = root->data.ViDu.pHead;
        while (vd != NULL)
        {	
			gotoxy(90,6+h+k);
            cout<<vd->data<<endl;
            vd = vd->next;
			k++;
        }
		int m=Max(i,k);
		h+=m;
		i=k=1;
		Xuat(root->right,h,i,k,z);
	}
}

Node* TimKiemTu(Tree root, char *key)
{
	if(root==NULL)
	   return NULL;
	
	// root->data.TuVung co dang "@abc\n"
	// can bien s de xu li chuoi thanh "abc" de so sanh voi key
	char s[100];
	strcpy(s,root->data.TuVung);
	XoaKiTu(s,'@');
    if(stricmp(s,key)==0)
       return root;
            
    if(stricmp(s,key)>0)
       return TimKiemTu(root->left,key);
            
     return TimKiemTu(root->right,key);
}

int GetDuLieu(Tree root,Word &word)
{
	Init(word.Nghia);
	Init(word.ViDu);
	fflush(stdin);
	gotoxy(10,12);
	gets(word.TuVung);

	Node *p = TimKiemTu(root,word.TuVung);
	// da tim thay nen bi trung, khong duoc them vao nua
	if(p != NULL)
		return -1;
	
	// nhap tu vung
	ThemKiTu(word.TuVung, '@');
	
	// nhap loai tu
	fflush(stdin);
	gotoxy(27,12);
	gets(word.LoaiTu);
	ThemKiTu(word.LoaiTu, '*');
	
	// nhap nghia + vi du 
	int flag;
	char Nghia[100];
	char ViDu[100];
	int x=12, i=0 ,k =1;

	do{
		
		fflush(stdin);
		gotoxy(47,x+i);
		gets(Nghia);
		ThemKiTu(Nghia, '-');
		AddTail(word.Nghia, Nghia);
		fflush(stdin);
		gotoxy(75,x+i);
		gets(ViDu);
		ThemKiTu(ViDu, '#');
		AddTail(word.ViDu, ViDu);
		i++;
		k++;
		if(k<6)
		{
			gotoxy(44,x+i);
			cout<<"1. Nhap Tiep:";
			cin >>flag;
			i++;
		}
		else
		{
			flag = 2;
		}	
	}while(flag==1); 
	
	
	return 1;
	
}

//kiem tra so nghia + vi du
int KTSoNghia(Node *p)
{	
	int count=0;
	NodeDS *nghia = p->data.Nghia.pHead;
	while(nghia!=NULL)
	{  	
		count++;                 	
		nghia = nghia->next;
	}
	return count;
}
//Them
void Them(Tree root)
{	
	Them();
    int choice;
	do{
		system("cls");
		Them();
		gotoxy(56,26);
		cin >> choice;
		
		switch(choice)
		{
			case 1:
			{
				system("cls");
				ThemTu();
				Word word;
				int kt = GetDuLieu(root,word);
				if(kt == -1)
				{
				   gotoxy(5,15);
				   cout<<"===> TU DA TON TAI";
				   getch();
				}
				else 
					root = InsertNode(root,word);
				break;
			}
			
			case 2:
			{		
			    
			    char key[100];
	            Node *p;
				int count=0;
	            
	            // Kiem tra tu nhap vao phai dung
	            do{	
					system("cls");
					ThemNghia();
					fflush(stdin);
					gotoxy(27,12);
					gets(key);
					if(stricmp(key, "0")==0)return;

					p = TimKiemTu(root, key);
					if(p==NULL)
					{	
						gotoxy(67,13);
						cout << "TU KHONG TON TAI.";
						sleep(2);
					}
					else
					{	
						count = KTSoNghia(p)+1;
						gotoxy(67,13);
						cout <<"TU TON TAI.";
						sleep(1);
					}
	    
	           }while(p==NULL);
				
				char ViDuThem[100];
				char NghiaThem[100];
			    int dem=0, flag2;
				if(count==6)
				{	
					gotoxy(31,16);
					cout<<"====> DA DAT GIOI HAN SO NGHIA <====";
					sleep(2);
					break;
				}
				else
				{
					do
					{	
						gotoxy(15,16+dem);
						cout<<"Nhap nghia: "<<count;
						gotoxy(15,17+dem);
						cout<<"Nhap vi du: ";
						fflush(stdin);
						gotoxy(31,16+dem);
						gets(NghiaThem);
						ThemKiTu(NghiaThem, '-');
						AddTail(p->data.Nghia, NghiaThem);
						fflush(stdin);
						gotoxy(31,17+dem);
						gets(ViDuThem);
						ThemKiTu(ViDuThem, '#');
						AddTail(p->data.ViDu, ViDuThem);
						if(count<5)
						{
							gotoxy(31,18+dem);
							cout <<"===> THEM DU LIEU NHAP 1: ";
							cin >>flag2;
							dem = dem+3;
							count ++;
						}
						else
						{
							flag2=2;
						}
						
					}while(flag2==1);
					break;		  			  
				}
			    
			}
			
			default: break;	
		}
		
	}while(choice!=0);
}
// Goi y tu
void GoiYTu(Tree root, char *word, int &soTu)
{
	if(root!=NULL)
	{
		// chi cho phep goi y ra 20 tu
		if(soTu<=20)
		{
			// bien de xu li chuoi
			char tempt[100];
			strcpy(tempt,root->data.TuVung);
			XoaKiTu(tempt, '@');
			XoaKiTu(tempt, '\n');
			
			char *s;
			gotoxy(4, 14+ soTu);
			s=strstr(tempt,word);
			
			if(s!=NULL && stricmp(tempt,s)==0)
			{
				soTu++;
				cout <<tempt <<endl;
			}
		}
		else
			return;
		GoiYTu(root->left, word, soTu);
		GoiYTu(root->right, word, soTu);
	}
}
// Tra tu dien
char TraTu(Tree root)
{
	// canh toa do
	int x= 10, y= 12;
    int m = x-6, n = y; 

	// tu vung de tim kiem
	char word[1000];
	// so luong tu trong word
	int dem=0;
	// bat su kien nhap vao
	int key;
	
	
	do{
		
		gotoxy(m, n);
		key = getch();
		
		if(key == 13) //Khi nhan nut Enter
		{
			// neu so tu == 0
			if(dem==0)
			{
			  	gotoxy(53,19);
			    cout << "===> BAN CHUA NHAP TU NAO <===";
			    
			    gotoxy(53,20);
			    cout << ".... VUI LONG NHAP TU VAO ....";
			    
			}
			else 
			{
				// tim kiem tu vung
				Node *p = TimKiemTu(root, word);
				
				if(p==NULL)
				{
					gotoxy(53,19);
			        cout<<"===> KHONG TIM THAY TU BAN CAN TIM <===";
			        gotoxy(53,20);
			        cout<<".... VUI LONG KIEM TRA LAI ....";
				}
				else // da tim duoc
				{
					// xuat loai tu
					gotoxy(53,12);
					char TemptLoaiTu[100];
					strcpy(TemptLoaiTu, p->data.LoaiTu);
					XoaKiTu(TemptLoaiTu, '*'); 	
   	                cout<<TemptLoaiTu;
   	                // xuat danh sach nghia
   	                int y=15,count=0;
   	                NodeDS *nghia = p->data.Nghia.pHead;
  	                while(nghia!=NULL)
   	                {  	               
					    gotoxy(51,y+count);  	
   	  	                cout << nghia->data;
   	  	                nghia = nghia->next;
   	  	                count++;
	                }
	                // xuat danh sach vi du
	                gotoxy(44, y+count+3); 
	                cout << "Vi du: \n";
	                NodeDS *vidu = p->data.ViDu.pHead;
   	                while(vidu!=NULL)
   	                {
   	                	gotoxy(51, y+count+4);
   	                	char TemptViDu[100];
					    strcpy(TemptViDu, vidu->data);
					    XoaKiTu(TemptViDu, '#'); 	
   	  	                cout << TemptViDu;
   	  	                vidu = vidu->next;
   	  	                count++;
	                }
				}
			}
		}	
			
        
		if( (key >= 97 && key <=122) || (key >=65 && key <= 90) || (key == 32) || (key == 39) || (key == 45) )
		{
				word[dem] = char(key);
				dem++;
				word[dem] = '\0';
				printf("%c", key);
				gotoxy(m++, n);
				XoaGoiY();
				XoaKetQuaTimKiem();
				int soTu=0;
				GoiYTu(root,word, soTu);
				
		}
		
		if(key == 8) //Khi nhan nut xoa, BackSpace
		{
				if(dem>0)
				{
					dem--;
					word[dem] = '\0';			
					gotoxy(--m, n);
					printf(" ");
					gotoxy(m, n);
					XoaGoiY();
					XoaKetQuaTimKiem();
					int soTu = 0;
					GoiYTu(root, word, soTu);
				}
				
					
				if(dem == 0)
				{	
						gotoxy(x-6, y+2);
						XoaGoiY();	
						XoaKetQuaTimKiem();
				}		
		}
				
   }while(key != 27 && key != 9); // 27: ESC, 9: Tab
   
	return key;

}

void CapNhatDSLKTheoSo(List &l, int stt, char *key)
{
	NodeDS *p = l.pHead;
	int dem=1;
	
	while(dem!=stt)
	{
		dem++;
		p = p->next;
	}
	strcpy(p->data, key);
}
// Sua chua cap nhat lai tu dien
void CapNhat(Tree &root)
{
	char TuCanTim[100];
    Node *p;
	// Kiem tra tu nhap vao phai dung 
	do{	
		system("cls");
		Sua();
	    fflush(stdin);
		gotoxy(27,12);
	    gets(TuCanTim);
	    if(stricmp(TuCanTim, "0") ==0 )
            return;
	    p = TimKiemTu(root, TuCanTim);
	    if(p==NULL)
        {	
			gotoxy(67,13);
            cout<<"TU KHONG TON TAI.\n";
			sleep(3);
        }
	    else
	    {	
			gotoxy(67,13);
	    	cout<< "TU TON TAI.";
			sleep(1);
		}
	    
	}while(p==NULL);
	
	
	int choice;
	do{
		
		system("cls");
        Sua1();
		gotoxy(56,30);
        cin>>choice;
		
		switch(choice)
		{
			
			case 1:
			{
				cout<<"\n =====> NHAP TU VU THAY DOI: ";
				char KeyTuVung[100];
				fflush(stdin);
				gets(KeyTuVung);
				ThemKiTu(KeyTuVung, '@');
				strcpy(p->data.TuVung, KeyTuVung);
				break;
			}
			
			case 2:
			{
				cout<<"\n=====> NHAP LOAI TU THAY DOI: ";
				char KeyLoaiTu[100];
				fflush(stdin);
				gets(KeyLoaiTu);
				ThemKiTu(KeyLoaiTu, '*');
				strcpy(p->data.LoaiTu, KeyLoaiTu);
				break;
			}
			
			case 3:
			{
				int choice3;
				do{
				    system("cls");
					DanhSachNghia();
				    int dem=0;
				    NodeDS *nghia = p->data.Nghia.pHead;
				    if(nghia == NULL)
				    {	
						gotoxy(35,9);
				    	cout<<"===> KHONG CO NGHIA NAO";
				    	getch();
				    	break;
					}
				    // xuat danh sach nghia
				    int k=0;
					while(nghia!=NULL)
				    {
				    	dem++;
				    	char tempt[100];
				    	strcpy(tempt, nghia->data);
				    	XoaKiTu(tempt, '-');
						gotoxy(35,9+k);
				    	cout << dem  << ")" <<tempt;
					    nghia = nghia->next;
						k++;
				    }
				    
				    
				    int SoCanSua;
				    do{	
						gotoxy(32,17);			    					    			    	
                        cout << "===> MOI NHAP LUA CHON CAN SUA: ";
						gotoxy(65,17);
                        cin >> SoCanSua;
					}while(SoCanSua < 1 || SoCanSua>dem);

					gotoxy(32,19);
				    cout << "===> NHAP NGHIA MOI: ";
				    char KeyNghia[100];
				    fflush(stdin);	
					gotoxy(55,19); 
				    gets(KeyNghia);
				    ThemKiTu(KeyNghia,'-');
				    CapNhatDSLKTheoSo(p->data.Nghia, SoCanSua, KeyNghia);
					gotoxy(32,20);
				    cout << "BAN CO MUON CAP NHAP TIEP HAY KHONG: 1) CO: ";
					gotoxy(76,20);
				    cin >> choice3;
				}while(choice3==1);
				
				break;
			}
			
			case 4:
			{
				int choice4;
				do{
					system("cls");
					DanhSachViDu();
				    int dem=0;
				    NodeDS *vidu = p->data.ViDu.pHead;
				    
				    if(vidu == NULL)
				    {	
						gotoxy(35,9);
				    	cout<<"===> KHONG CO VI DU NAO";
				    	getch();
				    	break;
					}
				    
				    // xuat danh sach nghia
					int k=0;
				    while(vidu!=NULL)
				    {
				    	dem++;
				    	char tempt[100];
				    	strcpy(tempt, vidu->data);
				    	XoaKiTu(tempt, '#');
						gotoxy(35,9+k);
				    	cout<<dem <<")" <<tempt;
					    vidu = vidu->next;
						k++;
				    }
				    
				    int SoCanSua;
				    do{
						gotoxy(32,17);
				    	cout<<"===> MOI NHAP LUA CHON CAN SUA: ";
						gotoxy(65,17);
                        cin>>SoCanSua;
					}while(SoCanSua < 1|| SoCanSua>dem);
				  	gotoxy(32,19);
				    cout << "===> NHAP VI DU MOI: ";
				    char KeyViDu[100];
				    fflush(stdin);
					gotoxy(55,19);
				    gets(KeyViDu);
				    ThemKiTu(KeyViDu,'#');
				    
				    CapNhatDSLKTheoSo(p->data.ViDu, SoCanSua, KeyViDu);
				    gotoxy(32,20);
				    cout << "BAN CO MUON CAP NHAT TIEP HAY KHONG: 1) CO: ";
				    gotoxy(76,20);
					cin >> choice4;
				}while(choice4==1);
				
				break;
			}
			
			default: break;
		}
	}while(choice!=0);
}
//Xoa node tren cay
void NodeTheMang(Tree &X, Tree &Y) 
{
	if (Y->left != NULL)
	{
		NodeTheMang(X, Y->left);
	}
	else 
	{
		X->data = Y->data; 
		X = Y; 
		Y = Y->right;
	}
}

void XoaNodeTrenCay(Tree &root, char *key)
{
	if (root == NULL)
	{
		return; 
	}
	else
	{
		if (stricmp(root->data.TuVung, key) >0 )
		{
			XoaNodeTrenCay(root->left, key); 
		}
		else if(stricmp(root->data.TuVung, key) <0 )
		{
			XoaNodeTrenCay(root->right, key); 
		}
		else 
		{
			Node *X = root;
		
			if (root->left == NULL)
			{
				root = root->right; 
			}
			else if (root->right == NULL)
			{
				
				root = root->left;
			}
			else 
			{	
				NodeTheMang(X, root->right);
			}
			delete X;
		}
	}
}

void XoaMotNode(List &l, NodeDS *nodecanxoa)
{
	if(l.pHead == nodecanxoa)
	{
		NodeDS *p = l.pHead;
	    l.pHead = l.pHead->next;
	    delete p;
	    return;
	}
	
	if(l.pTail == nodecanxoa)
	{
		NodeDS *p;
	    for(NodeDS *k = l.pHead; k!=NULL;k = k->next)
	    {
		   if(k == l.pTail)
          {
 	        l.pTail = p;
 	        l.pTail->next =NULL;
 	        delete k;
 	        return;
		   }
		   p = k;
	    }
	    return;
	}
	
	NodeDS *tam;
	for(NodeDS *p=l.pHead;p!=NULL;p=p->next)
	{
		if(p == nodecanxoa)
		{
			tam->next = p->next;
			delete p;
			return;
		}
		
		tam = p;
	}
}
//Xoa
void XoaDSLKDTheoSo(List &l, int stt)
{
	NodeDS *p = l.pHead;
	int dem=1;
	
	while(dem!=stt)
	{
		dem++;
		p = p->next;
	}
	XoaMotNode(l, p);
	
}

void Xoa(Tree &root)
{
	char key[100];
	Node *p;

	do{	
		system("cls");
		Xoa();
	    fflush(stdin);
		gotoxy(28,12);
	    gets(key);
	    if(stricmp(key, "0")==0)
			return;
	    p = TimKiemTu(root, key);
	    
	    if(p==NULL)
		{	
			gotoxy(67,13);
			cout << "TU KHONG TON TAI";
			sleep(2);
		}
			
	    else
	    {	
			gotoxy(67,13);
	    	cout << "TU TON TAI";
			sleep(1);
		}
	    
	}while(p==NULL);
	
	int choice;
	do{
		system("cls");
		Xoa1();
		gotoxy(58,30);
		cin >> choice;
		switch(choice)
		{
					
			case 1:
			{
				XoaNodeTrenCay(root, p->data.TuVung);
				choice = 5;
				break;
			}
			case 2:
			{
				char loaitu[20] = "";
				ThemKiTu(loaitu, '*');
				strcpy(p->data.LoaiTu, loaitu);
				break;
			}
			
			case 3:
			{
				int choice3;
				do{
					system("cls");
					DanhSachNghia();
				    int dem=0;
				    NodeDS *nghia = p->data.Nghia.pHead;
				    
				    if(nghia == NULL)
				    {	
						gotoxy(35,9);
				    	cout << "===> KHONG CO NGHIA NAO";
				    	getch();
				    	break;
					}
				    // xuat danh sach nghia
					int k=0;
				    while(nghia!=NULL)
				    {
				    	dem++;
				    	char tempt[100];
				    	strcpy(tempt, nghia->data);
				    	XoaKiTu(tempt, '-');
						gotoxy(35,9+k);
				    	cout <<dem << ")" <<tempt;
					    nghia = nghia->next;
				    	k++;
					}
				
				    int SoCanXoa;
				    do{	
						gotoxy(32,17);
						cout << "===> MOI NHAP LUA CHON CAN XOA: ";
						fflush(stdin);
						gotoxy(65,17);	
				        cin >> SoCanXoa;
					}while(SoCanXoa < 1|| SoCanXoa>dem);
				    XoaDSLKDTheoSo(p->data.Nghia, SoCanXoa);
					XoaDSLKDTheoSo(p->data.ViDu, SoCanXoa);
					gotoxy(32,20);
				    cout << "BAN CO MUON XOA TIEP HAY KHONG: 1) CO: ";
					gotoxy(76,20); 
				    cin >> choice3;
				}while(choice3==1);
				
				break;
			}		
			default: break;
		}
	}while(choice!=0);
}
//Xoa toan bo
Node *XoaToanBo(Tree &root)
{
		// if(root==NULL)
		// {
		// 	delete root;
		// 	return root;
		// }
		
		// else
		// {	
		// 	root->left =XoaToanBo(root->left);
		//  	root->right = XoaToanBo(root->right);
			
		// }
			root->left = XoaToanBo(root->left);
			root->right = XoaToanBo(root->right);
			free(root);
			return root;
		
	}
	
		
}

//Menu
void Menu(Tree root)
{
	int choice;
	do{
		
		system("cls");
		GiaoDienChinh();
		gotoxy(65,25);
		cin >> choice;
		
		switch(choice)
		{   
            case 1:
			{   
				char key;
				do{	
					system("cls");
					GiaoDienTraTu();
					key=TraTu(root);
				}while(key==9);
				break;
			}
			
			
			case 2:				
			{	
				system("cls");
				Them(root);		
			    break;	
			}
			case 3:
			{
				system("cls");
                CapNhat(root);
				break;
			}
				
			case 4:
			{   
				int key;
				do
				{
					system("cls");
					ChonXoa();
					gotoxy(56,22);
					cin>>key;
					switch(key)
					{
						case 1:
						{
							Xoa(root);
							break;
						}
						case 2:
						{
							XoaToanBo(root);

							break;
						}
							
					}
				} while (key!=0);
				break;
			}
			
			case 5:
            {	
				system("cls");
				int h=1, i=1,k=1,z=1;
				gotoxy(4,1);
				cout <<"=========CHU THICH.===========";
				gotoxy(3,2);
				cout <<" @ la tu vung.";
				gotoxy(20,2);
				cout <<" * la tu loai.";
				gotoxy(3,3);
				cout <<" - la nghia.";
				gotoxy(20,3);
				cout <<" # la vi du." <<endl;
				Xuat(root,h,i,k,z);
				//sleep(1000);
				system("pause");
				
				
				break;
			}
			default: break;
				  
		}
	}

	while(choice !=0);
}

int main()
{
	Tree root=NULL;
	// doc file ra cay
    ifstream filein;
	filein.open("data.txt");
	DocFile(root,filein);
	filein.close();
	Menu(root);
	ofstream fileout;
	fileout.open("data.txt", ios::out);
	GhiFile(root,fileout);
	fileout.close();
	return 0;
	
}